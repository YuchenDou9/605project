#!/bin/bash

cat *.tsv | sort -r -k 3,3 | head -5  > ratingRank.tsv
