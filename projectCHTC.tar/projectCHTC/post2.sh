#!/bin/bash

cat refinedData.tsv.* > job2out.tsv
