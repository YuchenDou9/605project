#!/bin/bash

rm collectedData.tsv.*
rm reformattedFile.*
rm jobout1
rm job1File

cat collectedData.tsv | awk -F"\t" '{if($12 == "Y"){print $5, $7, $8, $12, $15}}' > job2collectedData.tsv

nProcessors=50
data="job2collectedData.tsv"
nDataLines=$(wc -l < $data)
nLinesPerSplitFile=$(($nDataLines / $nProcessors))
remainder=$(($nDataLines % $nProcessors))
if [[ $remainder > 0 ]]; then
  nLinesPerSplitFile=$(($nLinesPerSplitFile + 1))
fi
split -d -l $nLinesPerSplitFile $data "$data."
