#!/bin/bash

while IFS= read -r line; do
 cat job2collectedData.tsv.$1 | awk -v a=$line '{if($1 == a){print $0}}'
done < top100 > refinedData.tsv.$1
