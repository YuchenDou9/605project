#!/bin/bash

rm -f log/* error/* output/*

#wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Automotive_v1_00.tsv.gz
#gzip -d amazon_reviews_us_Automotive_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Baby_v1_00.tsv.gz
gzip -d amazon_reviews_us_Baby_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Beauty_v1_00.tsv.gz
gzip -d amazon_reviews_us_Beauty_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Camera_v1_00.tsv.gz
gzip -d amazon_reviews_us_Camera_v1_00.tsv.gz

#wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Digital_Ebook_Purchase_v1_00.tsv.gz
#gzip -d amazon_reviews_us_Digital_Ebook_Purchase_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Digital_Ebook_Purchase_v1_01.tsv.gz
gzip -d amazon_reviews_us_Digital_Ebook_Purchase_v1_01.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Electronics_v1_00.tsv.gz
gzip -d amazon_reviews_us_Electronics_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Grocery_v1_00.tsv.gz
gzip -d amazon_reviews_us_Grocery_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Outdoors_v1_00.tsv.gz
gzip -d amazon_reviews_us_Outdoors_v1_00.tsv.gz

wget http://s3.amazonaws.com/amazon-reviews-pds/tsv/amazon_reviews_us_Digital_Video_Download_v1_00.tsv.gz
gzip -d amazon_reviews_us_Digital_Video_Download_v1_00.tsv.gz

cat amazon_reviews_us_Digital_Video_Download_v1_00.tsv amazon_reviews_us_Outdoors_v1_00.tsv amazon_reviews_us_Grocery_v1_00.tsv amazon_reviews_us_Electronics_v1_00.tsv amazon_reviews_us_Digital_Ebook_Purchase_v1_01.tsv > collectedData.tsv

rm amazon_reviews_us_Outdoors_v1_00.tsv
rm amazon_reviews_us_Digital_Video_Download_v1_00.tsv
rm amazon_reviews_us_Grocery_v1_00.tsv
rm amazon_reviews_us_Electronics_v1_00.tsv
rm amazon_reviews_us_Digital_Ebook_Purchase_v1_01.tsv

cat amazon_reviews_us_Camera_v1_00.tsv amazon_reviews_us_Baby_v1_00.tsv amazon_reviews_us_Beauty_v1_00.tsv >> collectedData.tsv

#rm amazon_reviews_us_Digital_Ebook_Purchase_v1_00.tsv 
rm amazon_reviews_us_Camera_v1_00.tsv 
rm amazon_reviews_us_Baby_v1_00.tsv 
rm amazon_reviews_us_Beauty_v1_00.tsv



nProcessors=50
data="collectedData.tsv"
nDataLines=$(wc -l < $data)
nLinesPerSplitFile=$(($nDataLines / $nProcessors))
remainder=$(($nDataLines % $nProcessors))
if [[ $remainder > 0 ]]; then
  nLinesPerSplitFile=$(($nLinesPerSplitFile + 1))
fi
split -d -l $nLinesPerSplitFile $data "$data."
