#!/bin/bash

rm -f log/* error/* output/*
rm job2collectedData.tsv.*
rm refinedData.tsv.*
awk '{$1=""}1' job2out.tsv
awk -F' ' '{print > $1".txt"}' job2out.tsv
