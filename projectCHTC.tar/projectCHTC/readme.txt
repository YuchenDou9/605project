Since we have three jobs in CHTC, please do job1.dag, job2.dag, split.sh, job3.sub in sequence.
Thank you very much!
the download link is https://github.com/YuchenDou9/605project.git
