#!/bin/bash


cat reformattedFile.* > job1File
uniq -c job1File | sort -nr > jobout1
cat jobout1| awk '{print $2}' | head -100 > top100
