rm(list=ls())


args = (commandArgs(trailingOnly=TRUE))
data = args[1]
table = read.table(data, header = FALSE, sep = " ")

aveRating <- data.frame(table[1,1], mean(table[,3]))
write.table(aveRating, file = paste(table[1,1], ".tsv", sep = ""), col.name = FALSE)