#!/bin/bash

awk -F"\t" '{if($12 == "N"){print $5}}' < collectedData.tsv.$1 | sort > reformattedFile.$1
